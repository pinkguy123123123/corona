Rails.application.routes.draw do
  get 'people/index'
  get 'people/new'
  get 'people/create'
  get 'people/person_params'
  get 'people/destroy'
  get 'groups/index'
  get 'groups/create'
  get 'groups/group_params'
  get 'groups/destroy'
  post 'groups/create'
  post 'people/create'
  resources :groups
  resources :people
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
