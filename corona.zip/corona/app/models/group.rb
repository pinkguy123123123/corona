class Group < ApplicationRecord
end
